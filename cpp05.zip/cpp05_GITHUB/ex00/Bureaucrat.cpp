/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>    				+#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 10:39:55 by ekocak            #+#    #+#             */
/*   Updated: 2023/07/18 14:05:59 by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"

Bureaucrat::Bureaucrat(void) : _grade(minGrade) 
{
    if (COMMENT)
        std::cout << "Default Constructor: <Bureaucrat(void)>" << std::endl;
}

Bureaucrat::Bureaucrat(const std::string theName) : _name(theName), _grade(minGrade)
{
    if (COMMENT)
    {
        std::cout << "Parametized Constructor: <Bureaucrat(std::string theName)> for " << theName << std::endl;
    }
}

Bureaucrat::Bureaucrat(const std::string theName, int theGrade) : _name(theName)
{

    if (theGrade > minGrade)
        throw GradeTooLowException();
    else
    {
        _grade = theGrade;
        if (COMMENT)
        {
            std::cout << "Parametized Constructor: " << *this << std::endl;
        }
    }
}

//Destructor
Bureaucrat::~Bureaucrat()
{
    if (COMMENT)
    {
        std::cout << "Destructor: " << _name << std::endl;
    }
}

//Copy Constructor
Bureaucrat::Bureaucrat(const Bureaucrat &other)
{
    *this = other;
    if (COMMENT)
    {
        std::cout << "Copy Constructing " << *this << " using " << other << std::endl;
    }
}

//Assignment operator overload
Bureaucrat &Bureaucrat::operator=(const Bureaucrat &other)
{
    if (this != &other)
    {
        _grade = other._grade;
    }
    if (COMMENT)
    {
        std::cout << "Assigning " << other << " to \"" << this->_name << "\"" << std::endl;
    }
    return (*this);
}

std::string Bureaucrat::getName(void) const
{
    return  (_name);
}

int Bureaucrat::getGrade(void) const
{
    return  (_grade);
}

void Bureaucrat::incrementGrade(void)
{
    incrementGrade(1);
}

void Bureaucrat::incrementGrade(int n)
{
    if (COMMENT)
    {
        std::cout << *this << " Incrementing Grade by " << n << std::endl;
    }
    try
    {
        if (_grade - n < maxGrade)
            throw Bureaucrat::GradeTooHighException();
        _grade -= n;
    }
    catch (GradeTooHighException &e)
    {
        std::cout << "GradeTooHighException caught. ";
        std::cout << e.what() << std::endl;
    }
}

void Bureaucrat::decrementGrade(void)
{
    decrementGrade(1);
}

void Bureaucrat::decrementGrade(int n)
{
    if (COMMENT)
    {
        std::cout << *this << " Decrementing Grade by " << n << " for " << _name << std::endl;
    }
    try
    {
        if (_grade + n > minGrade)
            throw Bureaucrat::GradeTooLowException();
        _grade += n;
    }
    catch (GradeTooLowException &e)
    {
        std::cout << "GradeTooLowException caught. ";
        std::cout << e.what() << std::endl;
    }
}

const char  *Bureaucrat::GradeTooHighException::what(void) const throw()
{
    return "The grade is beyond highest level. ";
} 

const char  *Bureaucrat::GradeTooLowException::what(void) const throw()
{
    return "The grade is beyond lowest level. ";
} 

std::ostream& operator<<(std::ostream& os, const Bureaucrat& bureaucrat) 
{
    os << "Bureaucrat: " << bureaucrat.getName() << ", Grade: " 
       << bureaucrat.getGrade();
    return os;
}