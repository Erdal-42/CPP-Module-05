/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>    				+#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/18 10:39:55 by ekocak            #+#    #+#             */
/*   Updated: 2023/07/18 14:05:59 by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"

//Constructors
Bureaucrat::Bureaucrat(void) : _grade(minGrade) 
{
    if (COMMENT)
        std::cout << "Default Constructor: <Bureaucrat(void)>" << std::endl;
}

Bureaucrat::Bureaucrat(const std::string theName) : _name(theName), _grade(minGrade)
{
    if (COMMENT)
    {
        std::cout << "Parametized Constructor: " << *this << std::endl;
    }
}

Bureaucrat::Bureaucrat(const std::string theName, int theGrade) : _name(theName)
{

    if (theGrade > minGrade)
        throw GradeTooLowException();
    else
    {
        _grade = theGrade;
        if (COMMENT)
        {
            std::cout << "Parametized Constructor: " << *this << std::endl;
        }
    }
}

//Destructor
Bureaucrat::~Bureaucrat()
{
    if (COMMENT)
    {
        std::cout << "Bureaucrat Destructor: " << _name << std::endl;
    }
}

//Copy Constructor
Bureaucrat::Bureaucrat(const Bureaucrat &other)
{
    *this = other;
    if (COMMENT)
    {
        std::cout << "Copy Constructing " << *this << " using " << other << std::endl;
    }
}

//Assignment operator overload
Bureaucrat &Bureaucrat::operator=(const Bureaucrat &other)
{
    if (this != &other)
    {
        _grade = other._grade;
    }
    if (COMMENT)
    {
        std::cout << "Assigning " << other << " to \"" << this->_name << "\"" << std::endl;
    }
    return (*this);
}

//Getters
const std::string Bureaucrat::getName(void) const
{
    return  (_name);
}

int Bureaucrat::getGrade(void) const
{
    return  (_grade);
}

//Miscellaneous
void Bureaucrat::incrementGrade(void)
{
    incrementGrade(1);
}

void Bureaucrat::incrementGrade(int n)
{
    if (COMMENT)
    {
        std::cout << *this << " Incrementing Grade by " << n << std::endl;
    }
    try
    {
        if (_grade - n < maxGrade)
            throw Bureaucrat::GradeTooHighException();
        _grade -= n;
    }
    catch (GradeTooHighException &e)
    {
        std::cout << "GradeTooHighException caught. ";
        std::cout << e.what() << std::endl;
    }
}

void Bureaucrat::decrementGrade(void)
{
    decrementGrade(1);
}

void Bureaucrat::decrementGrade(int n)
{
    if (COMMENT)
    {
        std::cout << *this << " Decrementing Grade by " << n << " for " << _name << std::endl;
    }
    try
    {
        if (_grade + n > minGrade)
            throw Bureaucrat::GradeTooLowException();
        _grade += n;
    }
    catch (GradeTooLowException &e)
    {
        std::cout << "GradeTooLowException caught. ";
        std::cout << e.what() << std::endl;
    }
}

void    Bureaucrat::signForm(Form &form) const
{
    if (!form.getSigned())
    {
        try
        {
            form.beSigned(*this);
            std::cout << *this << " signed " << form << std::endl;
        }
        catch(const std::exception& e)
        {
            std::cout << *this << " couldn't sign " << form << " because ";
            std::cerr << e.what() << '\n';
        }
    }
    else
    {
        std::cout << *this << " couldn't sign " << form << " because ";
        std::cout << "this form has already been signed. " << std::endl;
    }
}

const char  *Bureaucrat::GradeTooHighException::what(void) const throw()
{
    return "The grade is beyond the highest level 1. ";
} 

const char  *Bureaucrat::GradeTooLowException::what(void) const throw()
{
    return "The grade is beyond the lowest level 150. ";
}

// Non-member function to overload the << operator
std::ostream& operator<<(std::ostream& os, const Bureaucrat& bureaucrat) 
{
    os << "Bureaucrat: " << bureaucrat.getName() << ", Grade: ";
    if (bureaucrat.getGrade() <= 151 && bureaucrat.getGrade() >= 1) 
       os << bureaucrat.getGrade();
    return os;
}