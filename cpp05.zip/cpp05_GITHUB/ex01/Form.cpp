#include "Form.hpp"

Form::Form() : _name("Default"), _signed(false), _signGrade(Bureaucrat::minGrade), _execGrade(Bureaucrat::minGrade)
{
    if (COMMENT2)
    {
        std::cout << "Default Constructor: <Form(void)>" << std::endl;
    }
}
    
Form::Form(const std::string theName, const int theSignGrade, const int theExecGrade) : 
            _name(theName), _signed(false), _signGrade(theSignGrade), _execGrade(theExecGrade)
{
    if (_signGrade < Bureaucrat::maxGrade || _execGrade < Bureaucrat ::maxGrade)
        throw (Form::GradeTooHighException());
    if (_signGrade > Bureaucrat::minGrade || _execGrade > Bureaucrat::minGrade)
        throw (Form::GradeTooLowException());
    if (COMMENT2)
    {
        std::cout << "Parametized Constructor: " << *this << std::endl;
    }
}

//Destructor
Form::~Form()
{
    if (COMMENT2)
    {
        std::cout << "Form Destructor: " << getName() << std::endl;
    }
}

//Copy Constructor
Form::Form(const Form &other) : _name(other._name), 
                                _signed(other._signed), 
                                _signGrade(other._signGrade), 
                                _execGrade(other._execGrade) 
{
    if (COMMENT2)
    {
        std::cout << "Copy Constructing " << *this << " using " << other << std::endl;
    }
}

//Overload Assignment Operator
Form &Form::operator=(const Form &other)
{
    _signed = other._signed;
    return (*this);
}

//Getters
const std::string Form::getName() const
{
    return  (_name); 
}

bool        Form::getSigned() const
{
    return (_signed);
}

int         Form::getSignGrade() const
{
    return (_signGrade);
}

int         Form::getExecGrade() const
{
    return (_execGrade);
}

const char  *Form::GradeTooHighException::what(void) const throw()
{
    return "the grade is too high. ";
} 

const char  *Form::GradeTooLowException::what(void) const throw()
{
    return "the grade is too low. ";
}

void        Form::beSigned(const Bureaucrat &bureaucrat)
{
    if (_signed == true)
        return ;
    else if (bureaucrat.getGrade() <= getSignGrade())
    { 
        _signed = true;
        
    }
    else
        throw Form::GradeTooLowException();
}

// Non-member function to overload the << operator
std::ostream &operator<<(std::ostream & os, const Form &form) 
{
    os << "Form Name: " << form.getName();
    os << ", Form Signed: " << form.getSigned();
    os << ", Signature Grade: " << form.getSignGrade();
    os << ", Execution Grade: " << form.getExecGrade();
    return os;
}
